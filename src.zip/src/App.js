import React, { Component } from 'react';
import './App.css';
import Quiz from './Quiz';

class App extends Component {
  render() {
    return (
      <div className="App">
        
        
        <h1>RANDOMIZER QUIZ</h1>
        
        <Quiz/>
      </div>
    );
  }
}

export default App;
